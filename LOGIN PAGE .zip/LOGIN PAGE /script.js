// Add a delay for animation on page load
window.addEventListener('DOMContentLoaded', () => {
    const loginBox = document.querySelector('.login-box');
    loginBox.style.animationDelay = '0.3s';
  });
  
